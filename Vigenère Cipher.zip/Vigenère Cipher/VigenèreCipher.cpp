/*----------------------------------------------------------
------------        Vigen�re Cipher           --------------
------------              BY                  --------------
------------      Amna Azam - BSEF19M009      --------------
------------------------------------------------------------*/

/*REQUIREMENT::
    => A cipher function that should receive a key and a message.
    => It returns the ciphered text, a decipher function that should receive a cipher message and a key 
       and return the original deciphered text.
    => Implement a driver program that calls cipher and decipher functions to show their working.*/

/*LOGIC::
----------------------------------------------------------------
--------------------     FOR CIPHERED TEXT
---------------------------------------------------------------
        => Firstly, Make a key msg equal to the length of secrete msg.
        => To get ciphered text, if we add key character and secret msg character we get encoded character.

       ------------ REASON TO TAKE A MOD::
        => If sum of key's character and msg's character exceeded from alphabet's range (Z) then we need to subtract 26 from it.
        => Instead of subtracting 26 being good, take a mod with 26 was good approach. so, i used MOD for it.
 --------------------------------------------------------------------------------------------------------------------------------------
--------------------      FOR DECIPHERED TEXT
------------------------------------------------------------------
        => Firstly, Make a key msg equal to the length of secrete msg.
        => To get deCiphered text, if we subtract key character and secret msg character we get decoded character.

        ------------ REASON TO TAKE A MOD::
        => To avoid from negative answer after subtraction, we are adding 26 in each subtacted answer
           and taking mod with 26 to get just their difference (indifferent from sign).
        => Taking a mod with 26 balances us if we are adding 26 in positive answer getted after subtaction.

 P.S.
 we are subtracting 65 from capital alphabets and 97 from small alphabets
 beacause A's ascii and a's ascii starts from 65 and 97 respectivly.
 But after the all calculation we add their respective ascii in answer
 again to get required character.
*/

/*-------------------------------------------------------------------------------
-----------------------------   C++ IMPLEMENTATION    --------------------------- 
---------------------------------------------------------------------------------*/

#include<iostream>
#include<string>    
using namespace std;

bool isUpper(char ch)                     //is upper alphabet character?
{
    if (ch >= 'A' && ch <= 'Z')
        return true;
    else
       return false;
}
bool isLower(char ch)                                 //is lower alphabet character?
{
    if (ch >= 'a' && ch <= 'z')
        return true;
    else
       return false;
}
string generateEquiKey(string str, string key)        //Repeat key string untill its length becomes equal to secrete msg             
{
    string EquiLenStr = "";
    int i = 0;
    while(str.length() != EquiLenStr.length())
    {
        if (key.length() == i)          //key has attained its complete length ..... Initialize the key with 0 index.
            i = 0;
        string s(1, key[i]);      //convert character to string to append comfortabely
        EquiLenStr = EquiLenStr + s;
        i++;
    }
    return EquiLenStr;
}
string Cipher(string str, string key)
{
    string cipherMsg = "";
    int i = 0;
    char c;
    while (i != str.length())
    {
        //logic explained above... 
        if (isUpper(str[i]) && isUpper(key[i]))
            c = (((str[i] - 65) + (key[i] - 65)) % 26) + 65;     //here 65 is added to get string in capital letters(due to mam's sample output)
        else if (isLower(str[i]) && isLower(key[i]))
            c = (((str[i] - 97) + (key[i] - 97)) % 26) + 97;      //here 97 is added to get string in lower letters(due to mam's sample output)
        else if (isLower(str[i]) && isUpper(key[i]))
            c = (((str[i] - 97) + (key[i] - 65)) % 26) + 97;      //here 97 is added to get string in lower letters(due to mam's sample output)
        else if (isUpper(str[i]) && isLower(key[i]))
            c = (((str[i] - 65) + (key[i] - 97)) % 26) + 65;       //here 65 is added to get string in capital letters(due to mam's sample output)
        else
            c = str[i];
        string s(1, c);       //convert character to string to append comfortabely
        cipherMsg = cipherMsg + s;    
        i++;
    }
    return cipherMsg;
}
string Decipher(string str, string key)
{
    string deCipherMsg = "";
    int i = 0;
    char c;
    while (i != str.length())
    {
        //logic explained above...
        if (isUpper(str[i]) && isUpper(key[i]))
            c = ((((str[i] - 65) - (key[i] - 65)) + 26) % 26) + 97;      //here 97 is added to get string in small letters(due to mam's sample output)
        else if (isLower(str[i]) && isLower(key[i]))
            c = ((((str[i] - 97) - (key[i] - 97)) + 26) % 26) + 65;      //here 65 is added to get string in capital letters(due to mam's sample output)
        else if (isUpper(str[i]) && isLower(key[i]))
            c = ((((str[i] - 65) - (key[i] - 97)) + 26) % 26) + 97;      //here 97 is added to get string in small letters(due to mam's sample output)
        else if (isLower(str[i]) && isUpper(key[i]))
            c = ((((str[i] - 97) - (key[i] - 65)) + 26) % 26) + 65;      //here 65 is added to get string in capital letters(due to mam's sample output)
        else
            c = str[i];
        string s(1, c);       //convert character to string to append comfortabely
        deCipherMsg = deCipherMsg + s;
        i++;
    }
    return deCipherMsg;
}
int main()
{
    string str;
    cout << "\n******** -----   ENCRYPTION   ----- ********\n";
    cout << "Enter the Secrete Message :: ";
    getline(cin, str);
    cout << "Enter the cipher Key :: ";
    string key;
    getline(cin, key);
    if(key.length()<str.length())
        key = generateEquiKey(str, key);
    cout << "Output :: " << Cipher(str, key);
    cout << "\n\n\n\n******** -----  DYSCRIPTION  ----- ********\n";
    cout << "Enter the cipher message :: ";
    getline(cin, str);
    cout << "Enter cipher key :: ";
    getline(cin, key);
    if (key.length() < str.length())
    key = generateEquiKey(str, key);
    cout << "Output :: " << Decipher(str, key)<<"\n\n\n";
    cout << "Program ended successfully....";
	return 0;
}